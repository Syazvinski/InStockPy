from mainObjOriented import main
